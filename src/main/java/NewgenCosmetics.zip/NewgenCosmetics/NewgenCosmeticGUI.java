package NewgenCosmetics;

import NewgenCosmetics.command.CosmeticCommand;
import NewgenCosmetics.command.CosmeticTabCompleter;
import NewgenCosmetics.db.DatabaseManager;
import NewgenCosmetics.gui.*;
import NewgenCosmetics.listener.*;
import NewgenCosmetics.service.CosmeticService;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public final class NewgenCosmeticGUI extends JavaPlugin {

    private DatabaseManager databaseManager;
    private CosmeticService cosmeticService;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        databaseManager = new DatabaseManager(this);
        databaseManager.init();

        cosmeticService = new CosmeticService(this, databaseManager);

        CosmeticWardrobeGui wardrobeGui = new CosmeticWardrobeGui(this, cosmeticService);

        // ✅ manage GUIs
        AdminManageListGui manageListGui = new AdminManageListGui(this, cosmeticService);
        AdminManageEditGui manageEditGui = new AdminManageEditGui(this, cosmeticService);

        Bukkit.getPluginManager().registerEvents(new GuiListener(cosmeticService), this);
        Bukkit.getPluginManager().registerEvents(new CosmeticEquipListener(cosmeticService), this);
        Bukkit.getPluginManager().registerEvents(new WardrobeListener(wardrobeGui, cosmeticService), this);
        Bukkit.getPluginManager().registerEvents(new JoinEquipListener(this, cosmeticService), this);

        // ✅ manage listener
        Bukkit.getPluginManager().registerEvents(new AdminManageListener(cosmeticService, manageListGui, manageEditGui), this);

        var cmd = getCommand("cosmetic");
        if (cmd != null) {
            cmd.setExecutor(new CosmeticCommand(this, cosmeticService, wardrobeGui, manageListGui, manageEditGui));
            cmd.setTabCompleter(new CosmeticTabCompleter(cosmeticService));
        }

        getLogger().info("Enabled NewgenCosmetics");
    }

    @Override
    public void onDisable() {
        if (databaseManager != null) databaseManager.close();
    }
}
